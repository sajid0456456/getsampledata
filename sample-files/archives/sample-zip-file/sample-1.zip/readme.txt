Sample archive contents.
GetSampleData.com
